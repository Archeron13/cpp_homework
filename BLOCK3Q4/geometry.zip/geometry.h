#include <cmath>
#include <vector>
#include <iostream>

#include "shape.h"
#include "polygon.h"
#include "circle.h"
#include "rectangle.h"
#include "square.h"
#include "triangle.h"
